package controller;


import javax.swing.JOptionPane;
import view.NiveisT3;
import view.NiveisT4;

/**
 *
 * @author Gabriela
 */
public class Contador {
    public int cont1 = 0;
    public int cont2 = 0;
    public int cont3 = 0;
    
    public void acertouN1() {
      cont1++;
    }
    public void acertouN2(){
        cont2++;
    }
    public void acertouN3(){
        cont3++;
    }
    
    public void passou1(){
        if (cont1>=3) {
          JOptionPane.showMessageDialog(null, "Você Passou de Nível!!\nClique em OK para continuar");
          NiveisT3 n3 = new NiveisT3();
          n3.setVisible(true);   
        }
        else{
            JOptionPane.showMessageDialog(null, "Você Não atingiu a pontuação correta.\nTente outra vez");
        }
    }
    
    public void passou2(){
        if (cont2>4) {
          JOptionPane.showMessageDialog(null, "Você Passou de Nível!!\nClique em OK para continuar");
          NiveisT4 n4 = new NiveisT4();
          n4.setVisible(true);   
        }
        else{
            JOptionPane.showMessageDialog(null, "Você Não atingiu a pontuação correta.\nTente outra vez");
        }
    
    }
     public void passou3(){
        if (cont3>=5) {
          JOptionPane.showMessageDialog(null, "Você venceu o Jogo!\nParabéns você sabe muito sobre meio ambiente");
          NiveisT4 n4 = new NiveisT4();
          n4.setVisible(true);   
        }
        else{
            JOptionPane.showMessageDialog(null, "Você Não atingiu a pontuação correta.\nTente outra vez");
        }
    }
    
}
