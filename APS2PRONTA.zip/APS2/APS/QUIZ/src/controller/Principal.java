package controller;

import model.Jogador;
import view.BemvindoT1;
import controller.Contador;

public class Principal {
    
    private static Jogador jogador;

    public static void main(String[] args) {
        BemvindoT1 t1 = new BemvindoT1();
        t1.setVisible(true);     
       Contador cont = new Contador();
       
    }
    public static void setJogador(Jogador j) {
        jogador = j;
    }    
    
}
