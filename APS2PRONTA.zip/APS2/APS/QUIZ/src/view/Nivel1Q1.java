
package view;

import controller.Contador;
import controller.Principal;
import model.Jogador;
import javafx.scene.paint.Color;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import javax.swing.UIManager;


public class Nivel1Q1 extends javax.swing.JFrame {
    

    public Nivel1Q1() {
        initComponents();
        ButtonGroup bt1 = new ButtonGroup();
        bt1.add(btrA11);
        bt1.add(btrB11);
        bt1.add(btrC11);
        bt1.add(btrD11);  

        ButtonGroup bt2 = new ButtonGroup();
        bt2.add(btrA12);
        bt2.add(btrB12);
        bt2.add(btrC12);
        bt2.add(btrD12);
        
        ButtonGroup bt3 = new ButtonGroup();
        bt3.add(btrA13);
        bt3.add(btrB13);
        
        ButtonGroup bt4 = new ButtonGroup();
        bt4.add(btrA14);
        bt4.add(btrB14);
        bt4.add(btrC14);
        bt4.add(btrD14);
        
        ButtonGroup bt5 = new ButtonGroup();
        bt5.add(btrA15);
        bt5.add(btrB15);
        bt5.add(btrC15);
        bt5.add(btrD15);
 
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnN1 = new javax.swing.JPanel();
        lbN1q1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        lbQ1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        btConferir11 = new javax.swing.JButton();
        btrA11 = new javax.swing.JRadioButton();
        btrB11 = new javax.swing.JRadioButton();
        btrD11 = new javax.swing.JRadioButton();
        btrC11 = new javax.swing.JRadioButton();
        jPanel3 = new javax.swing.JPanel();
        lbQ2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        btrA12 = new javax.swing.JRadioButton();
        btrB12 = new javax.swing.JRadioButton();
        btrD12 = new javax.swing.JRadioButton();
        btrC12 = new javax.swing.JRadioButton();
        btConferir12 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        lbQ4 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea4 = new javax.swing.JTextArea();
        btConferir14 = new javax.swing.JButton();
        btrA14 = new javax.swing.JRadioButton();
        btrB14 = new javax.swing.JRadioButton();
        btrD14 = new javax.swing.JRadioButton();
        btrC14 = new javax.swing.JRadioButton();
        lbQ5 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        lbQ3 = new javax.swing.JLabel();
        btConferir13 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btrB13 = new javax.swing.JRadioButton();
        btrA13 = new javax.swing.JRadioButton();
        jPanel25 = new javax.swing.JPanel();
        lbQ6 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTextArea5 = new javax.swing.JTextArea();
        btConferir15 = new javax.swing.JButton();
        btrA15 = new javax.swing.JRadioButton();
        btrB15 = new javax.swing.JRadioButton();
        btrD15 = new javax.swing.JRadioButton();
        btrC15 = new javax.swing.JRadioButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        conferirPontos1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnN1.setBackground(new java.awt.Color(145, 255, 82));
        pnN1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 102, 0), 3));

        lbN1q1.setFont(new java.awt.Font("Candara", 3, 36)); // NOI18N
        lbN1q1.setText("NÍVEL 1");

        javax.swing.GroupLayout pnN1Layout = new javax.swing.GroupLayout(pnN1);
        pnN1.setLayout(pnN1Layout);
        pnN1Layout.setHorizontalGroup(
            pnN1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnN1Layout.createSequentialGroup()
                .addGap(131, 131, 131)
                .addComponent(lbN1q1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnN1Layout.setVerticalGroup(
            pnN1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnN1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lbN1q1)
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(184, 255, 127));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 51), 4));

        lbQ1.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        lbQ1.setText("1) O que é meio ambiente? ");

        jTextArea2.setEditable(false);
        jTextArea2.setColumns(20);
        jTextArea2.setFont(new java.awt.Font("Candara", 0, 18)); // NOI18N
        jTextArea2.setRows(5);
        jTextArea2.setText("a)É o centro de um local onde pessoas ficam.\nb)É uma ONG brasileira pró natureza.\nc)É um conjunto de elementos que podem de alguma maneira causar efeito sobre os seres vivos da Terra.\nd)É o nome dado ao conjunto de árvores e plantas existentes.\n");
        jScrollPane2.setViewportView(jTextArea2);

        btConferir11.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        btConferir11.setText("Conferir");
        btConferir11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btConferir11MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btConferir11MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btConferir11MouseExited(evt);
            }
        });

        btrA11.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrA11.setText("A");

        btrB11.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrB11.setText("B");

        btrD11.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrD11.setText("D");

        btrC11.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrC11.setText("C");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbQ1)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btrA11)
                        .addGap(10, 10, 10)
                        .addComponent(btrB11)
                        .addGap(18, 18, 18)
                        .addComponent(btrC11)
                        .addGap(10, 10, 10)
                        .addComponent(btrD11)))
                .addContainerGap(73, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(btConferir11, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbQ1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btrA11)
                    .addComponent(btrD11)
                    .addComponent(btrC11)
                    .addComponent(btrB11))
                .addGap(18, 18, 18)
                .addComponent(btConferir11, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(184, 255, 127));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 51), 4));

        lbQ2.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        lbQ2.setText("2) O que é um ser vivo?");

        jTextArea3.setEditable(false);
        jTextArea3.setColumns(20);
        jTextArea3.setFont(new java.awt.Font("Candara", 0, 18)); // NOI18N
        jTextArea3.setRows(5);
        jTextArea3.setText("a)Um ser humano.\nb)Seres humanos e plantas.\nc)Todo ser que reproduz energia sozinho.\nd)Todo tipo de matéria da Terra.\n");
        jScrollPane3.setViewportView(jTextArea3);

        btrA12.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrA12.setText("A");

        btrB12.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrB12.setText("B");

        btrD12.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrD12.setText("D");

        btrC12.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrC12.setText("C");

        btConferir12.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        btConferir12.setText("Conferir");
        btConferir12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btConferir12MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 315, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lbQ2))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addComponent(btrA12)
                                .addGap(18, 18, 18)
                                .addComponent(btrB12)
                                .addGap(18, 18, 18)
                                .addComponent(btrC12))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(51, 51, 51)
                                .addComponent(btConferir12, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(btrD12)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbQ2)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btrC12)
                    .addComponent(btrD12)
                    .addComponent(btrB12)
                    .addComponent(btrA12))
                .addGap(18, 18, 18)
                .addComponent(btConferir12, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel5.setBackground(new java.awt.Color(184, 255, 127));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 51), 4));

        lbQ4.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        lbQ4.setText("4)Selecione uma prática que atrapalhe ");

        jTextArea4.setEditable(false);
        jTextArea4.setColumns(20);
        jTextArea4.setFont(new java.awt.Font("Candara", 0, 18)); // NOI18N
        jTextArea4.setRows(5);
        jTextArea4.setText("a)Poluição.\nb)Chuvas.\nc)Cortar a grama.\nd)Ser vegetariano.\n");
        jScrollPane4.setViewportView(jTextArea4);

        btConferir14.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        btConferir14.setText("Conferir");
        btConferir14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btConferir14MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btConferir14MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btConferir14MouseExited(evt);
            }
        });
        btConferir14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btConferir14ActionPerformed(evt);
            }
        });

        btrA14.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrA14.setText("A");

        btrB14.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrB14.setText("B");

        btrD14.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrD14.setText("D");

        btrC14.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrC14.setText("C");

        lbQ5.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        lbQ5.setText("o meio ambiente de maneira grave:");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(lbQ4)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addComponent(btConferir14, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(169, 169, 169))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addComponent(btrA14)
                                .addGap(18, 18, 18)
                                .addComponent(btrB14)
                                .addGap(18, 18, 18)
                                .addComponent(btrC14)
                                .addGap(18, 18, 18)
                                .addComponent(btrD14)
                                .addGap(116, 116, 116))))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(lbQ5)
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(lbQ4)
                .addGap(1, 1, 1)
                .addComponent(lbQ5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btrA14)
                    .addComponent(btrD14)
                    .addComponent(btrC14)
                    .addComponent(btrB14))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                .addComponent(btConferir14, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        jPanel4.setBackground(new java.awt.Color(184, 255, 127));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 51), 4));

        lbQ3.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        lbQ3.setText("3)“A preservação do meio ambiente NÃO depende");

        btConferir13.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        btConferir13.setText("Conferir");
        btConferir13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btConferir13MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btConferir13MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btConferir13MouseExited(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        jLabel1.setText(" dos seres humanos. ”");

        btrB13.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrB13.setText("Falso");

        btrA13.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrA13.setText("Verdadeiro");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(btrA13)
                                .addGap(26, 26, 26)
                                .addComponent(btrB13))
                            .addComponent(lbQ3)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel1))))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(75, 75, 75)
                        .addComponent(btConferir13, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbQ3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btrA13)
                    .addComponent(btrB13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btConferir13, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel25.setBackground(new java.awt.Color(184, 255, 127));
        jPanel25.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 51), 4));

        lbQ6.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        lbQ6.setText("5)____ é uma maneira de preservar o meio ambiente.");

        jTextArea5.setEditable(false);
        jTextArea5.setColumns(20);
        jTextArea5.setFont(new java.awt.Font("Candara", 0, 18)); // NOI18N
        jTextArea5.setRows(5);
        jTextArea5.setText("a)Desmatamento.\nb)Reflorestamento.\nc)Panfletagem. \nd)Palestra.\n");
        jScrollPane5.setViewportView(jTextArea5);

        btConferir15.setFont(new java.awt.Font("Candara", 1, 18)); // NOI18N
        btConferir15.setText("Conferir");
        btConferir15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btConferir15MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btConferir15MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btConferir15MouseExited(evt);
            }
        });

        btrA15.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrA15.setText("A");

        btrB15.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrB15.setText("B");

        btrD15.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrD15.setText("D");

        btrC15.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        btrC15.setText("C");

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbQ6, javax.swing.GroupLayout.DEFAULT_SIZE, 422, Short.MAX_VALUE)
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel25Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(btrA15)
                                .addGap(18, 18, 18)
                                .addComponent(btrB15)
                                .addGap(18, 18, 18)
                                .addComponent(btrC15)
                                .addGap(18, 18, 18)
                                .addComponent(btrD15)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(140, 140, 140)
                .addComponent(btConferir15, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbQ6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btrA15)
                    .addComponent(btrD15)
                    .addComponent(btrC15)
                    .addComponent(btrB15))
                .addGap(38, 38, 38)
                .addComponent(btConferir15, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(184, 255, 127));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 51), 4));

        jLabel2.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel2.setText("Tem certeza de todas as suas respostas?");

        jLabel3.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel3.setText("Se sim, clique em conferir para");

        jLabel4.setFont(new java.awt.Font("Candara", 1, 14)); // NOI18N
        jLabel4.setText("ir para o próximo nível.");

        conferirPontos1.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        conferirPontos1.setText("Conferir");
        conferirPontos1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                conferirPontos1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                conferirPontos1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                conferirPontos1MouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(conferirPontos1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addGap(65, 65, 65)
                .addComponent(conferirPontos1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnN1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnN1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btConferir11MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btConferir11MouseEntered
        btConferir11.setForeground(java.awt.Color.GREEN);
    }//GEN-LAST:event_btConferir11MouseEntered

    private void btConferir11MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btConferir11MouseExited
        btConferir11.setForeground(java.awt.Color.BLACK);
    }//GEN-LAST:event_btConferir11MouseExited

   //q1 
    private void btConferir11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btConferir11MouseClicked
        if(btrC11.isSelected()){
            JOptionPane.showMessageDialog(null, "Você acertou!!");  
        }
        else{
            JOptionPane.showMessageDialog(null, "Você errou. Resposta correta: C"); 
        }
//Conferindo resposta da 1 correta
     /* Contador cont = new Contador();
        if (btrC11.isSelected()){   
            cont.acertouN1();
            UIManager.put("OptionPane.okButtonText", "Próximo");
            JOptionPane.showMessageDialog(null, "Você acertou!!");        
        }
        else {
        UIManager.put("OptionPane.okButtonText", "Próximo");
        JOptionPane.showMessageDialog(null, "Você errou. Resposta correta: C"); 
        }*/
    }//GEN-LAST:event_btConferir11MouseClicked
//q2
    private void btConferir12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btConferir12MouseClicked
         if(btrC12.isSelected()){
            JOptionPane.showMessageDialog(null, "Você acertou!!");  
        }
        else{
            JOptionPane.showMessageDialog(null, "Você errou. Resposta correta: C"); 
        }
    }//GEN-LAST:event_btConferir12MouseClicked
//q3
    private void btConferir13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btConferir13MouseClicked
        if(btrB13.isSelected()){
          JOptionPane.showMessageDialog(null, "Você acertou!!"); 
        }
        else{
            JOptionPane.showMessageDialog(null, "Você errou. Resposta correta: Verdadeiro"); 
        }
     
    }//GEN-LAST:event_btConferir13MouseClicked

    private void btConferir13MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btConferir13MouseEntered
        btConferir13.setForeground(java.awt.Color.GREEN);
    }//GEN-LAST:event_btConferir13MouseEntered

    private void btConferir13MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btConferir13MouseExited
        btConferir13.setForeground(java.awt.Color.BLACK);
    }//GEN-LAST:event_btConferir13MouseExited
//q4
    private void btConferir14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btConferir14MouseClicked
        if (btrA14.isSelected()){
            JOptionPane.showMessageDialog(null, "Você acertou!!");
        }
        else{
            JOptionPane.showMessageDialog(null, "Você errou. Resposta correta: A");
        }
    }//GEN-LAST:event_btConferir14MouseClicked

    private void btConferir14MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btConferir14MouseEntered
        btConferir14.setForeground(java.awt.Color.GREEN);
    }//GEN-LAST:event_btConferir14MouseEntered

    private void btConferir14MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btConferir14MouseExited
        btConferir14.setForeground(java.awt.Color.BLACK);
    }//GEN-LAST:event_btConferir14MouseExited

    private void btConferir14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btConferir14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btConferir14ActionPerformed
//q5
    private void btConferir15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btConferir15MouseClicked
        if(btrB15.isSelected()){
             JOptionPane.showMessageDialog(null, "Você acertou!!");
        }
        else{
            JOptionPane.showMessageDialog(null, "Você errou. Resposta correta: B");
        }
    }//GEN-LAST:event_btConferir15MouseClicked

    private void btConferir15MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btConferir15MouseEntered
        btConferir15.setForeground(java.awt.Color.GREEN);
    }//GEN-LAST:event_btConferir15MouseEntered

    private void btConferir15MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btConferir15MouseExited
        btConferir15.setForeground(java.awt.Color.BLACK);
    }//GEN-LAST:event_btConferir15MouseExited

    private void conferirPontos1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_conferirPontos1MouseEntered
        conferirPontos1.setForeground(java.awt.Color.GREEN);
    }//GEN-LAST:event_conferirPontos1MouseEntered

    private void conferirPontos1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_conferirPontos1MouseExited
        conferirPontos1.setForeground(java.awt.Color.BLACK);
    }//GEN-LAST:event_conferirPontos1MouseExited

    private void conferirPontos1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_conferirPontos1MouseClicked
        Contador cont = new Contador();
        if(btrC11.isSelected()){   
            cont.acertouN1();
        }
        if(btrC12.isSelected()){
            cont.acertouN1();   
        }
        if(btrB13.isSelected()){
            cont.acertouN1();
        }
        if(btrA14.isSelected()){
            cont.acertouN1();
        }
        if(btrB15.isSelected()){
            cont.acertouN1();
        } 
        cont.passou1();
        this.dispose();
    }//GEN-LAST:event_conferirPontos1MouseClicked

    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Nivel1Q1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btConferir11;
    private javax.swing.JButton btConferir12;
    private javax.swing.JButton btConferir13;
    private javax.swing.JButton btConferir14;
    private javax.swing.JButton btConferir15;
    private javax.swing.JRadioButton btrA11;
    private javax.swing.JRadioButton btrA12;
    private javax.swing.JRadioButton btrA13;
    private javax.swing.JRadioButton btrA14;
    private javax.swing.JRadioButton btrA15;
    private javax.swing.JRadioButton btrB11;
    private javax.swing.JRadioButton btrB12;
    private javax.swing.JRadioButton btrB13;
    private javax.swing.JRadioButton btrB14;
    private javax.swing.JRadioButton btrB15;
    private javax.swing.JRadioButton btrC11;
    private javax.swing.JRadioButton btrC12;
    private javax.swing.JRadioButton btrC14;
    private javax.swing.JRadioButton btrC15;
    private javax.swing.JRadioButton btrD11;
    private javax.swing.JRadioButton btrD12;
    private javax.swing.JRadioButton btrD14;
    private javax.swing.JRadioButton btrD15;
    private javax.swing.JButton conferirPontos1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextArea jTextArea4;
    private javax.swing.JTextArea jTextArea5;
    private javax.swing.JLabel lbN1q1;
    private javax.swing.JLabel lbQ1;
    private javax.swing.JLabel lbQ2;
    private javax.swing.JLabel lbQ3;
    private javax.swing.JLabel lbQ4;
    private javax.swing.JLabel lbQ5;
    private javax.swing.JLabel lbQ6;
    private javax.swing.JPanel pnN1;
    // End of variables declaration//GEN-END:variables



}
